import {
  Chip,
  ChipClasses,
  ChipModule,
  ChipStyle
} from "./chunk-V3GQPONV.js";
import "./chunk-BATKJCOQ.js";
import "./chunk-RT5JBLXN.js";
import "./chunk-WONKKWWV.js";
import "./chunk-YPYFYVEU.js";
import "./chunk-GUBNNMHS.js";
import "./chunk-MEHXH6ZQ.js";
import "./chunk-PEBH6BBU.js";
import "./chunk-WPM5VTLQ.js";
import "./chunk-4S3KYZTJ.js";
import "./chunk-WDMUDEB6.js";
export {
  Chip,
  ChipClasses,
  ChipModule,
  ChipStyle
};
//# sourceMappingURL=primeng_chip.js.map
