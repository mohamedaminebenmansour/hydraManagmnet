import {
  CHECKBOX_VALUE_ACCESSOR,
  Checkbox,
  CheckboxClasses,
  CheckboxModule,
  CheckboxStyle
} from "./chunk-XHPHEDH5.js";
import "./chunk-BATKJCOQ.js";
import "./chunk-RT5JBLXN.js";
import "./chunk-WONKKWWV.js";
import "./chunk-YPYFYVEU.js";
import "./chunk-UXM7BPGO.js";
import "./chunk-GUBNNMHS.js";
import "./chunk-MEHXH6ZQ.js";
import "./chunk-PEBH6BBU.js";
import "./chunk-WPM5VTLQ.js";
import "./chunk-4S3KYZTJ.js";
import "./chunk-WDMUDEB6.js";
export {
  CHECKBOX_VALUE_ACCESSOR,
  Checkbox,
  CheckboxClasses,
  CheckboxModule,
  CheckboxStyle
};
//# sourceMappingURL=primeng_checkbox.js.map
