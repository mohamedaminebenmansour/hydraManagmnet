import {
  Badge,
  BadgeClasses,
  BadgeDirective,
  BadgeModule,
  BadgeStyle
} from "./chunk-6F2AGOGR.js";
import "./chunk-RT5JBLXN.js";
import "./chunk-WONKKWWV.js";
import "./chunk-YPYFYVEU.js";
import "./chunk-GUBNNMHS.js";
import "./chunk-MEHXH6ZQ.js";
import "./chunk-PEBH6BBU.js";
import "./chunk-WPM5VTLQ.js";
import "./chunk-4S3KYZTJ.js";
import "./chunk-WDMUDEB6.js";
export {
  Badge,
  BadgeClasses,
  BadgeDirective,
  BadgeModule,
  BadgeStyle
};
//# sourceMappingURL=primeng_badge.js.map
