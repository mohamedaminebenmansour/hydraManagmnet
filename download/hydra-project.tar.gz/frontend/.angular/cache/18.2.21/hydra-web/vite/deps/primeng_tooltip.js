import {
  Tooltip,
  TooltipClasses,
  TooltipModule,
  TooltipStyle
} from "./chunk-ZDRTXB44.js";
import "./chunk-AHMOI77P.js";
import "./chunk-5G7WYC4N.js";
import "./chunk-RT5JBLXN.js";
import "./chunk-WONKKWWV.js";
import "./chunk-YPYFYVEU.js";
import "./chunk-GUBNNMHS.js";
import "./chunk-MEHXH6ZQ.js";
import "./chunk-PEBH6BBU.js";
import "./chunk-WPM5VTLQ.js";
import "./chunk-4S3KYZTJ.js";
import "./chunk-WDMUDEB6.js";
export {
  Tooltip,
  TooltipClasses,
  TooltipModule,
  TooltipStyle
};
//# sourceMappingURL=primeng_tooltip.js.map
